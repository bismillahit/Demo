<form action="<?php echo base_url()."pre_registration_protal/add_edit"; ?>" method="post" role="form" id="form" enctype="multipart/form-data" style="padding: 0px 30px">
 <?php if(isset($data->pre_registration_protal_id)){?><input type="hidden"  name="id" value="<?php echo isset($data->pre_registration_protal_id) ?$data->pre_registration_protal_id : "";?>"> <?php } ?>
 <div class="box-body"><div class="form-group">
			 		<label for="registration_serial_number_">Registration Serial Number  <span class="text-red">*</span></label>
<input type="number" placeholder=" Registration Serial Number " class="form-control" id="registration_serial_number_" name="registration_serial_number_" required value="<?php echo isset($data->registration_serial_number_)?$data->registration_serial_number_:"";?>"  >
</div>
<div class="form-group">
			 		<label for="agency_licence_number">Agency Licence Number <span class="text-red">*</span></label>
<input type="number" placeholder=" Agency Licence Number" class="form-control" id="agency_licence_number" name="agency_licence_number" required value="<?php echo isset($data->agency_licence_number)?$data->agency_licence_number:"";?>"  >
</div>
<div class="form-group">
			 		<label for="gender_type_">Gender Type  <span class="text-red">*</span></label>
<br><input type="radio"  name="gender_type_" required value="Male"  <?php if(isset($data->gender_type_) && ($data->gender_type_ == "Male")){ echo "checked";}?> > Male
<br><input type="radio"  name="gender_type_" required value="Female"  <?php if(isset($data->gender_type_) && ($data->gender_type_ == "Female")){ echo "checked";}?> > Female
</div>
<div class="form-group">
			 		<label for="full_name_as_per_national_id_card">Full Name As Per National Id Card <span class="text-red">*</span></label>
<input type="text" placeholder=" Full Name As Per National Id Card" class="form-control" id="full_name_as_per_national_id_card" name="full_name_as_per_national_id_card" required value="<?php echo isset($data->full_name_as_per_national_id_card)?$data->full_name_as_per_national_id_card:"";?>"  >
</div>
<div class="form-group">
			 		<label for="relationship_">Relationship  <span class="text-red">*</span></label>
<select name="relationship_" class="form-control" id="relationship_"  required>
								<option value=""></option>
                        			<option value="Fathers Name" <?php if(isset($data->relationship_) && ($data->relationship_ == "Fathers Name")){ echo "selected";}?>>Fathers Name</option>
<option value="" <?php if(isset($data->relationship_) && ($data->relationship_ == "")){ echo "selected";}?>></option>
<option value="Husband Name" <?php if(isset($data->relationship_) && ($data->relationship_ == "Husband Name")){ echo "selected";}?>>Husband Name</option>
</select>
</div>
<div class="form-group">
			 		<label for="relationship_person_name">Relationship Person Name <span class="text-red">*</span></label>
<input type="text" placeholder=" Relationship Person Name" class="form-control" id="relationship_person_name" name="relationship_person_name" required value="<?php echo isset($data->relationship_person_name)?$data->relationship_person_name:"";?>"  >
</div>
<div class="form-group">
			 		<label for="mothers_name_as_per_national_id_card">Mothers Name As Per National Id Card <span class="text-red">*</span></label>
<input type="text" placeholder=" Mothers Name As Per National Id Card" class="form-control" id="mothers_name_as_per_national_id_card" name="mothers_name_as_per_national_id_card" required value="<?php echo isset($data->mothers_name_as_per_national_id_card)?$data->mothers_name_as_per_national_id_card:"";?>"  >
</div>
</div>
                  <!-- /.box-body -->
                  <div class="box-footer">
                  	 <input type="submit" value="Save" name="save" class="btn btn-primary btn-color">
                  </div>
               </form>