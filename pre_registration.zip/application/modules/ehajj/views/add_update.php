<form action="<?php echo base_url()."ehajj/add_edit"; ?>" method="post" role="form" id="form" enctype="multipart/form-data" style="padding: 0px 30px">
 <?php if(isset($data->ehajj_id)){?><input type="hidden"  name="id" value="<?php echo isset($data->ehajj_id) ?$data->ehajj_id : "";?>"> <?php } ?>
 <div class="box-body"><div class="form-group">
			 		<label for="registration_serial_number_">Registration Serial Number  <span class="text-red">*</span></label>
<input type="number" placeholder=" Registration Serial Number " class="form-control" id="registration_serial_number_" name="registration_serial_number_" required value="<?php echo isset($data->registration_serial_number_)?$data->registration_serial_number_:"";?>"  >
</div>
<div class="form-group">
			 		<label for="pre_registation_haji_name">Pre Registation Haji Name <span class="text-red">*</span></label>
<input type="text" placeholder=" Pre Registation Haji Name" class="form-control" id="pre_registation_haji_name" name="pre_registation_haji_name" required value="<?php echo isset($data->pre_registation_haji_name)?$data->pre_registation_haji_name:"";?>"  >
</div>
<div class="form-group">
			 		<label for="passport_number">Passport Number <span class="text-red">*</span></label>
<input type="text" placeholder=" Passport Number" class="form-control" id="passport_number" name="passport_number" required value="<?php echo isset($data->passport_number)?$data->passport_number:"";?>"  >
</div>
<div class="form-group">
			 		<label for="passport_issue_date">Passport Issue Date <span class="text-red">*</span></label>
<input type="date" placeholder=" Passport Issue Date" class="form-control" id="passport_issue_date" name="passport_issue_date" required value="<?php echo isset($data->passport_issue_date)?date("Y-m-d",strtotime($data->passport_issue_date)):date("Y-m-d",strtotime("now"));?>"  >
</div>
<div class="form-group">
			 		<label for="passport_expire_date">Passport Expire Date <span class="text-red">*</span></label>
<input type="date" placeholder=" Passport Expire Date" class="form-control" id="passport_expire_date" name="passport_expire_date" required value="<?php echo isset($data->passport_expire_date)?date("Y-m-d",strtotime($data->passport_expire_date)):date("Y-m-d",strtotime("now"));?>"  >
</div>
<div class="form-group">
			 		<label for="files_upload">Files Upload </label>
<?php  
                        if( isset($data->files_upload) && !empty($data->files_upload)){ $req ="";}else{$req ="";}
						if(isset($data->files_upload))
						{ 
							?>
							<input type="hidden"  name="fileOld" value="<?php echo isset($data->files_upload) ?$data->files_upload : "";?>">
							<a href="<?php echo base_url().'assets/images/'.$data->files_upload ?>" download> <?php echo $data->files_upload; ?> </a>
						<?php 
						} 
						?>
						<input type="file" placeholder=" Files Upload" class="file-upload" id="files_upload" name="files_upload[]" <?php echo $req; ?> multiple value="" onchange='validate_fileType(this.value,&quot;files_upload&quot;,&quot;jpg,doc etc.&quot;);' ><p id="error_files_upload"></p>
</div>
</div>
                  <!-- /.box-body -->
                  <div class="box-footer">
                  	 <input type="submit" value="Save" name="save" class="btn btn-primary btn-color">
                  </div>
               </form>