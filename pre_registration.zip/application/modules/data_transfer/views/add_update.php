<form action="<?php echo base_url()."data_transfer/add_edit"; ?>" method="post" role="form" id="form" enctype="multipart/form-data" style="padding: 0px 30px">
 <?php if(isset($data->data_transfer_id)){?><input type="hidden"  name="id" value="<?php echo isset($data->data_transfer_id) ?$data->data_transfer_id : "";?>"> <?php } ?>
 <div class="box-body"><div class="form-group">
			 		<label for="agency_name">Agency Name <span class="text-red">*</span></label>
<input type="text" placeholder=" Agency Name" class="form-control" id="agency_name" name="agency_name" required value="<?php echo isset($data->agency_name)?$data->agency_name:"";?>"  >
</div>
<div class="form-group">
			 		<label for="agency_licence_number">Agency Licence Number <span class="text-red">*</span></label>
<input type="number" placeholder=" Agency Licence Number" class="form-control" id="agency_licence_number" name="agency_licence_number" required value="<?php echo isset($data->agency_licence_number)?$data->agency_licence_number:"";?>"  >
</div>
<div class="form-group">
			 		<label for="enquirer_">Enquirer  <span class="text-red">*</span></label>
<select name="enquirer_" class="form-control" id="enquirer_"  required>
								<option value=""></option>
                        			<option value="Data Transfer" <?php if(isset($data->enquirer_) && ($data->enquirer_ == "Data Transfer")){ echo "selected";}?>>Data Transfer</option>
<option value="Data Receive " <?php if(isset($data->enquirer_) && ($data->enquirer_ == "Data Receive ")){ echo "selected";}?>>Data Receive </option>
<option value="Data Delete" <?php if(isset($data->enquirer_) && ($data->enquirer_ == "Data Delete")){ echo "selected";}?>>Data Delete</option>
</select>
</div>
<div class="form-group">
			 		<label for="registration_serial_number_">Registration Serial Number  <span class="text-red">*</span></label>
<input type="number" placeholder=" Registration Serial Number " class="form-control" id="registration_serial_number_" name="registration_serial_number_" required value="<?php echo isset($data->registration_serial_number_)?$data->registration_serial_number_:"";?>"  >
</div>
<div class="form-group">
			 		<label for="national_id_number">NATIONAL ID Number <span class="text-red">*</span></label>
<input type="number" placeholder=" NATIONAL ID Number" class="form-control" id="national_id_number" name="national_id_number" required value="<?php echo isset($data->national_id_number)?$data->national_id_number:"";?>"  >
</div>
<div class="form-group">
			 		<label for="reason_for_tf">Reason For TF <span class="text-red">*</span></label>
<textarea rows="2" class="form-control" id="reason_for_tf" name="reason_for_tf" required><?php echo isset($data->reason_for_tf)?$data->reason_for_tf:"";?></textarea>
</div>
</div>
                  <!-- /.box-body -->
                  <div class="box-footer">
                  	 <input type="submit" value="Save" name="save" class="btn btn-primary btn-color">
                  </div>
               </form>