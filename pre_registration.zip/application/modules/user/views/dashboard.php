<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper clearfix">
	<div class="col-md-12 form f-label">
		<?php if($this->session->flashdata("messagePr")){?>
	    	<div class="alert alert-info">      
	      		<?php echo $this->session->flashdata("messagePr")?>
	    	</div>
	  	<?php } ?>
	  	<div class="box box-success pad-dashboard">
			<div class="box-header with-border">
		        <h3 class="box-title"> Dashboard</h3>
		    </div>
		    <div class="box-body">
		    	<div class="row dash">
		    		<div class="col-md-3">
			          	<div class="info-box ">
			            	<span class="info-box-icon bg-aqua" style="background-color: #000000 !important;"><span class="glyphicon glyphicon-list-alt"></span></span>
			            	<div class="info-box-content">
			              		<span class="info-box-text">Pilgrim Processing Entry</span>
			              		<span class="info-box-number"><?php echo isset($info_box['pre_registration_protal_count'])?$info_box['pre_registration_protal_count']:'0'; ?></span>
			            	</div>
			            <!-- /.info-box-content -->
			          	</div>
			          <!-- /.info-box -->
			        </div>
		    		<div class="col-md-3">
			          	<div class="info-box ">
			            	<span class="info-box-icon bg-aqua" style="background-color: #1d7326 !important;"><span class="glyphicon glyphicon-warning-sign"></span></span>
			            	<div class="info-box-content">
			              		<span class="info-box-text">Pilgrim Entry Limit</span>
			              		<span class="info-box-number"><?php echo isset($info_box['pre_registration_protal_count'])?$info_box['pre_registration_protal_count']:'0'; ?></span>
			            	</div>
			            <!-- /.info-box-content -->
			          	</div>
			          <!-- /.info-box -->
			        </div>
		    		<div class="col-md-3">
			          	<div class="info-box ">
			            	<span class="info-box-icon bg-aqua" style="background-color: #000000 !important;"><span class="glyphicon glyphicon-refresh"></span></span>
			            	<div class="info-box-content">
			              		<span class="info-box-text">Pilgrim Processing </span>
			              		<span class="info-box-number"><?php echo isset($info_box['registration_process_count'])?$info_box['registration_process_count']:'0'; ?></span>
			            	</div>
			            <!-- /.info-box-content -->
			          	</div>
			          <!-- /.info-box -->
			        </div>
		    		<div class="col-md-3">
			          	<div class="info-box ">
			            	<span class="info-box-icon bg-aqua" style="background-color: #000000 !important;"><span class="glyphicon glyphicon-ok"></span></span>
			            	<div class="info-box-content">
			              		<span class="info-box-text">Pilgrim Verifications</span>
			              		<span class="info-box-number"><?php echo isset($info_box['verification__condition'])?$info_box['verification__condition']:'0'; ?></span>
			            	</div>
			            <!-- /.info-box-content -->
			          	</div>
			          <!-- /.info-box -->
			        </div>
		    		<div class="col-md-3">
			          	<div class="info-box ">
			            	<span class="info-box-icon bg-aqua" style="background-color: #d67037 !important;"><span class="glyphicon glyphicon-refresh"></span></span>
			            	<div class="info-box-content">
			              		<span class="info-box-text">eHajj Status</span>
			              		<span class="info-box-number"><?php echo isset($info_box['ehajj_count'])?$info_box['ehajj_count']:'0'; ?></span>
			            	</div>
			            <!-- /.info-box-content -->
			          	</div>
			          <!-- /.info-box -->
			        </div>
		    		<div class="col-md-3">
			          	<div class="info-box ">
			            	<span class="info-box-icon bg-aqua" style="background-color: #ff0000 !important;"><span class="glyphicon glyphicon-user"></span></span>
			            	<div class="info-box-content">
			              		<span class="info-box-text">Support</span>
			              		<span class="info-box-number"><?php echo isset($info_box['support_Select Action'])?$info_box['support_Select Action']:'0'; ?></span>
			            	</div>
			            <!-- /.info-box-content -->
			          	</div>
			          <!-- /.info-box -->
			        </div>
		    		<div class="col-md-3">
			          	<div class="info-box ">
			            	<span class="info-box-icon bg-aqua" style="background-color: #edae0d !important;"><span class="glyphicon glyphicon-adjust"></span></span>
			            	<div class="info-box-content">
			              		<span class="info-box-text">Agency Count</span>
			              		<span class="info-box-number"><?php echo isset($info_box['users_count'])?$info_box['users_count']:'0'; ?></span>
			            	</div>
			            <!-- /.info-box-content -->
			          	</div>
			          <!-- /.info-box -->
			        </div>
		    		<div class="col-md-3">
			          	<div class="info-box ">
			            	<span class="info-box-icon bg-aqua" style="background-color: #f70101 !important;"><span class="glyphicon glyphicon-download-alt"></span></span>
			            	<div class="info-box-content">
			              		<span class="info-box-text">EQUATION </span>
			              		<span class="info-box-number"><?php echo isset($info_box['data_transfer_sum'])?$info_box['data_transfer_sum']:'0'; ?></span>
			            	</div>
			            <!-- /.info-box-content -->
			          	</div>
			          <!-- /.info-box -->
			        </div>
		    	</div>
		    </div>
	  	</div>
	</div>
</div>
		