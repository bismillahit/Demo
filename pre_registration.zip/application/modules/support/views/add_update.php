<form action="<?php echo base_url()."support/add_edit"; ?>" method="post" role="form" id="form" enctype="multipart/form-data" style="padding: 0px 30px">
 <?php if(isset($data->support_id)){?><input type="hidden"  name="id" value="<?php echo isset($data->support_id) ?$data->support_id : "";?>"> <?php } ?>
 <div class="box-body"><div class="heedingInformStyle">Any Issue or Complain Please Tell Us</div>
<div class="form-group">
			 		<label for="customer_support_inquiry_">Customer Support Inquiry  <span class="text-red">*</span></label>
<select name="customer_support_inquiry_" class="form-control" id="customer_support_inquiry_"  required>
								<option value=""></option>
                        			<option value="New Registration Entry Problem" <?php if(isset($data->customer_support_inquiry_) && ($data->customer_support_inquiry_ == "New Registration Entry Problem")){ echo "selected";}?>>New Registration Entry Problem</option>
<option value="National Id Card Verification Problem" <?php if(isset($data->customer_support_inquiry_) && ($data->customer_support_inquiry_ == "National Id Card Verification Problem")){ echo "selected";}?>>National Id Card Verification Problem</option>
<option value="Agent Account Setting Problem" <?php if(isset($data->customer_support_inquiry_) && ($data->customer_support_inquiry_ == "Agent Account Setting Problem")){ echo "selected";}?>>Agent Account Setting Problem</option>
<option value="Photo Uploading Problem" <?php if(isset($data->customer_support_inquiry_) && ($data->customer_support_inquiry_ == "Photo Uploading Problem")){ echo "selected";}?>>Photo Uploading Problem</option>
<option value="Status Pending " <?php if(isset($data->customer_support_inquiry_) && ($data->customer_support_inquiry_ == "Status Pending ")){ echo "selected";}?>>Status Pending </option>
<option value="Verification Pending" <?php if(isset($data->customer_support_inquiry_) && ($data->customer_support_inquiry_ == "Verification Pending")){ echo "selected";}?>>Verification Pending</option>
<option value="New Agent Account Create " <?php if(isset($data->customer_support_inquiry_) && ($data->customer_support_inquiry_ == "New Agent Account Create ")){ echo "selected";}?>>New Agent Account Create </option>
<option value="Registration Pilgrim Transfer" <?php if(isset($data->customer_support_inquiry_) && ($data->customer_support_inquiry_ == "Registration Pilgrim Transfer")){ echo "selected";}?>>Registration Pilgrim Transfer</option>
<option value="Registration Pilgrim Statu" <?php if(isset($data->customer_support_inquiry_) && ($data->customer_support_inquiry_ == "Registration Pilgrim Statu")){ echo "selected";}?>>Registration Pilgrim Statu</option>
</select>
</div>
<div class="form-group">
			 		<label for="your_message_">Your Message  <span class="text-red">*</span></label>
<textarea rows="3" class="form-control" id="your_message_" name="your_message_" required><?php echo isset($data->your_message_)?$data->your_message_:"";?></textarea>
</div>
<div class="form-group">
			 		<label for="upload_your_issue_">Upload Your Issue  </label>
<?php  
                        if( isset($data->upload_your_issue_) && !empty($data->upload_your_issue_)){ $req ="";}else{$req ="";}
						if(isset($data->upload_your_issue_))
						{ 
							?>
							<input type="hidden"  name="fileOld" value="<?php echo isset($data->upload_your_issue_) ?$data->upload_your_issue_ : "";?>">
							<a href="<?php echo base_url().'assets/images/'.$data->upload_your_issue_ ?>" download> <?php echo $data->upload_your_issue_; ?> </a>
						<?php 
						} 
						?>
						<input type="file" placeholder=" Upload Your Issue " class="file-upload" id="upload_your_issue_" name="upload_your_issue_[]" <?php echo $req; ?>  value="" onchange='validate_fileType(this.value,&quot;upload_your_issue_&quot;,&quot;jpg,doc etc..&quot;);' ><p id="error_upload_your_issue_"></p>
</div>
</div>
                  <!-- /.box-body -->
                  <div class="box-footer">
                  	 <input type="submit" value="Save" name="save" class="btn btn-primary btn-color">
                  </div>
               </form>