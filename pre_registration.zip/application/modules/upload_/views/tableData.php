<?php 
			$tablename = "upload_";
			$tab_id = $tablename.'_id';
			if(isset($view_data) && is_array($view_data) && !empty($view_data)) { 
  foreach ($view_data as $key => $value) {?>
  <tr>
<td>
				<?php 
					if(CheckPermission("test_crud", "all_delete")){
					      echo '<input type="checkbox" name="selData" value="'.$value->$tab_id.'">';}
					      else if(CheckPermission("test_crud", "own_delete") && (CheckPermission("test_crud", "all_delete")!=true)){
					        $user_id =getRowByTableColomId("test_crud",$value->$tab_id,$tab_id,"user_id");
					        if($user_id==$this->user_id){
					      echo '<input type="checkbox" name="selData" value="'.$value->$tab_id.'">';
					        }
					      }
					?>
			</td><td><?php echo $value->national_id_card_; ?></td>
<td><?php echo $value->n_id_card_upload; ?></td>
<td><?php echo $value->agency_latter_upload; ?></td>
<td><?php echo $value->file_upload; ?></td>
<td><?php echo $value->others; ?></td>
<td><?php echo $value->others_; ?></td>
<td><?php 
	      if(CheckPermission("upload_", "all_update")){
	      echo '<a sty id="btnEditRow" class="modalButton mClass"  href="javascript:;" type="button" data-src="'.$value->$tab_id.'" title="Edit"><i class="fa fa-pencil" data-id=""></i></a>';
	      }else if(CheckPermission("upload_", "own_update") && (CheckPermission("upload_", "all_update")!=true)){
	        $user_id =getRowByTableColomId("upload_",$value->$tab_id,$tab_id,"user_id");
	        if($user_id==$this->user_id){
	      echo '<a sty id="btnEditRow" class="modalButton mClass"  href="javascript:;" type="button" data-src="'.$value->$tab_id.'" title="Edit"><i class="fa fa-pencil" data-id=""></i></a>';
	        }
	      }
	      
	      if(CheckPermission("upload_", "all_delete")){
	      echo '<a data-toggle="modal" class="mClass" style="cursor:pointer;"  data-target="#cnfrm_delete" title="delete" onclick="setId('.$value->$tab_id.', \'upload_\')"><i class="fa fa-trash-o" ></i></a>';}
	      else if(CheckPermission("upload_", "own_delete") && (CheckPermission("upload_", "all_delete")!=true)){
	        $user_id =getRowByTableColomId("upload_",$value->$tab_id,$tab_id,"user_id");
	        if($user_id==$this->user_id){
	      echo '<a data-toggle="modal" class="mClass" style="cursor:pointer;"  data-target="#cnfrm_delete" title="delete" onclick="setId('.$value->$tab_id.', \'upload_\')"><i class="fa fa-trash-o" ></i></a>';
	        }
	      } ?>
	    </td>
	  </tr>    

	  
	<?php } } ?>
