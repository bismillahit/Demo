<form action="<?php echo base_url()."upload_/add_edit"; ?>" method="post" role="form" id="form" enctype="multipart/form-data" style="padding: 0px 30px">
 <?php if(isset($data->upload__id)){?><input type="hidden"  name="id" value="<?php echo isset($data->upload__id) ?$data->upload__id : "";?>"> <?php } ?>
 <div class="box-body"><div class="form-group">
			 		<label for="national_id_card_">NATIONAL ID CARD  </label>
<input type="text" placeholder=" NATIONAL ID CARD " class="form-control" id="national_id_card_" name="national_id_card_"  value="<?php echo isset($data->national_id_card_)?$data->national_id_card_:"";?>"  >
</div>
<div class="form-group">
			 		<label for="n_id_card_upload">N Id Card Upload </label>
<?php  
                        if( isset($data->n_id_card_upload) && !empty($data->n_id_card_upload)){ $req ="";}else{$req ="";}
						if(isset($data->n_id_card_upload))
						{ 
							?>
							<input type="hidden"  name="fileOld" value="<?php echo isset($data->n_id_card_upload) ?$data->n_id_card_upload : "";?>">
							<a href="<?php echo base_url().'assets/images/'.$data->n_id_card_upload ?>" download> <?php echo $data->n_id_card_upload; ?> </a>
						<?php 
						} 
						?>
						<input type="file" placeholder=" N Id Card Upload" class="file-upload" id="n_id_card_upload" name="n_id_card_upload[]" <?php echo $req; ?>  value="" onchange='validate_fileType(this.value,&quot;n_id_card_upload&quot;,&quot;jpg,doc etc.&quot;);' ><p id="error_n_id_card_upload"></p>
</div>
<div class="form-group">
			 		<label for="agency_latter_upload">Agency Latter Upload </label>
<input type="text" placeholder=" Agency Latter Upload" class="form-control" id="agency_latter_upload" name="agency_latter_upload"  value="<?php echo isset($data->agency_latter_upload)?$data->agency_latter_upload:"";?>"  >
</div>
<div class="form-group">
			 		<label for="file_upload">File Upload </label>
<?php  
                        if( isset($data->file_upload) && !empty($data->file_upload)){ $req ="";}else{$req ="";}
						if(isset($data->file_upload))
						{ 
							?>
							<input type="hidden"  name="fileOld" value="<?php echo isset($data->file_upload) ?$data->file_upload : "";?>">
							<a href="<?php echo base_url().'assets/images/'.$data->file_upload ?>" download> <?php echo $data->file_upload; ?> </a>
						<?php 
						} 
						?>
						<input type="file" placeholder=" File Upload" class="file-upload" id="file_upload" name="file_upload[]" <?php echo $req; ?>  value="" onchange='validate_fileType(this.value,&quot;file_upload&quot;,&quot;jpg,doc etc.&quot;);' ><p id="error_file_upload"></p>
</div>
<div class="form-group">
			 		<label for="others">Others </label>
<input type="text" placeholder=" Others" class="form-control" id="others" name="others"  value="<?php echo isset($data->others)?$data->others:"";?>"  >
</div>
<div class="form-group">
			 		<label for="others_">Others  </label>
<?php  
                        if( isset($data->others_) && !empty($data->others_)){ $req ="";}else{$req ="";}
						if(isset($data->others_))
						{ 
							?>
							<input type="hidden"  name="fileOld" value="<?php echo isset($data->others_) ?$data->others_ : "";?>">
							<a href="<?php echo base_url().'assets/images/'.$data->others_ ?>" download> <?php echo $data->others_; ?> </a>
						<?php 
						} 
						?>
						<input type="file" placeholder=" Others " class="file-upload" id="others_" name="others_[]" <?php echo $req; ?>  value="" onchange='validate_fileType(this.value,&quot;others_&quot;,&quot;jpg,doc etc.&quot;);' ><p id="error_others_"></p>
</div>
</div>
                  <!-- /.box-body -->
                  <div class="box-footer">
                  	 <input type="submit" value="Save" name="save" class="btn btn-primary btn-color">
                  </div>
               </form>