<form action="<?php echo base_url()."verification_/add_edit"; ?>" method="post" role="form" id="form" enctype="multipart/form-data" style="padding: 0px 30px">
 <?php if(isset($data->verification__id)){?><input type="hidden"  name="id" value="<?php echo isset($data->verification__id) ?$data->verification__id : "";?>"> <?php } ?>
 <div class="box-body"><div class="heedingInformStyle">NATIONAL ID CARD VERIFICATION REPORT</div>
<div class="form-group">
			 		<label for="agency_name">Agency Name <span class="text-red">*</span></label>
<input type="text" placeholder=" Agency Name" class="form-control" id="agency_name" name="agency_name" required value="<?php echo isset($data->agency_name)?$data->agency_name:"";?>"  >
</div>
<div class="form-group">
			 		<label for="agency_licence_number">Agency Licence Number <span class="text-red">*</span></label>
<input type="number" placeholder=" Agency Licence Number" class="form-control" id="agency_licence_number" name="agency_licence_number" required value="<?php echo isset($data->agency_licence_number)?$data->agency_licence_number:"";?>"  >
</div>
<div class="form-group">
			 		<label for="registration_serial_number_">Registration Serial Number  <span class="text-red">*</span></label>
<input type="number" placeholder=" Registration Serial Number " class="form-control" id="registration_serial_number_" name="registration_serial_number_" required value="<?php echo isset($data->registration_serial_number_)?$data->registration_serial_number_:"";?>"  >
</div>
<div class="form-group">
			 		<label for="national_id_number">National Id Number <span class="text-red">*</span></label>
<input type="number" placeholder=" National Id Number" class="form-control" id="national_id_number" name="national_id_number" required value="<?php echo isset($data->national_id_number)?$data->national_id_number:"";?>"  >
</div>
</div>
                  <!-- /.box-body -->
                  <div class="box-footer">
                  	 <input type="submit" value="Save" name="save" class="btn btn-primary btn-color">
                  </div>
               </form>