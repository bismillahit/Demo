<form action="<?php echo base_url()."registration_process/add_edit"; ?>" method="post" role="form" id="form" enctype="multipart/form-data" style="padding: 0px 30px">
 <?php if(isset($data->registration_process_id)){?><input type="hidden"  name="id" value="<?php echo isset($data->registration_process_id) ?$data->registration_process_id : "";?>"> <?php } ?>
 <div class="box-body"><div class="form-group">
			 		<label for="registration_serial_number_">Registration Serial Number  <span class="text-red">*</span></label>
<input type="number" placeholder=" Registration Serial Number " class="form-control" id="registration_serial_number_" name="registration_serial_number_" required value="<?php echo isset($data->registration_serial_number_)?$data->registration_serial_number_:"";?>"  >
</div>
<div class="form-group">
			 		<label for="date_of_birth_as_per_national_id_card">Date Of Birth As Per National Id Card <span class="text-red">*</span></label>
<input type="date" placeholder=" Date Of Birth As Per National Id Card" class="form-control" id="date_of_birth_as_per_national_id_card" name="date_of_birth_as_per_national_id_card" required value="<?php echo isset($data->date_of_birth_as_per_national_id_card)?date("Y-m-d",strtotime($data->date_of_birth_as_per_national_id_card)):date("Y-m-d",strtotime("now"));?>"  >
</div>
<div class="form-group">
			 		<label for="national_id_number">National Id Number <span class="text-red">*</span></label>
<input type="number" placeholder=" National Id Number" class="form-control" id="national_id_number" name="national_id_number" required value="<?php echo isset($data->national_id_number)?$data->national_id_number:"";?>"  >
</div>
<div class="form-group">
			 		<label for="mobile_number">Mobile Number <span class="text-red">*</span></label>
<input type="number" placeholder=" Mobile Number" class="form-control" id="mobile_number" name="mobile_number" required value="<?php echo isset($data->mobile_number)?$data->mobile_number:"";?>"  >
</div>
<div class="form-group">
			 		<label for="present_address">Present Address <span class="text-red">*</span></label>
<textarea rows="2" class="form-control" id="present_address" name="present_address" required><?php echo isset($data->present_address)?$data->present_address:"";?></textarea>
</div>
<div class="form-group">
			 		<label for="permanent_address">Permanent Address <span class="text-red">*</span></label>
<textarea rows="2" class="form-control" id="permanent_address" name="permanent_address" required><?php echo isset($data->permanent_address)?$data->permanent_address:"";?></textarea>
</div>
</div>
                  <!-- /.box-body -->
                  <div class="box-footer">
                  	 <input type="submit" value="Save" name="save" class="btn btn-primary btn-color">
                  </div>
               </form>