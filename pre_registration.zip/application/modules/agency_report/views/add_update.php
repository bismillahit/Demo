<form action="<?php echo base_url()."agency_report/add_edit"; ?>" method="post" role="form" id="form" enctype="multipart/form-data" style="padding: 0px 30px">
 <?php if(isset($data->agency_report_id)){?><input type="hidden"  name="id" value="<?php echo isset($data->agency_report_id) ?$data->agency_report_id : "";?>"> <?php } ?>
 <div class="box-body"><div class="form-group">
			 		<label for="agency_name">Agency Name <span class="text-red">*</span></label>
<input type="text" placeholder=" Agency Name" class="form-control" id="agency_name" name="agency_name" required value="<?php echo isset($data->agency_name)?$data->agency_name:"";?>"  >
</div>
<div class="form-group">
			 		<label for="agency_licence_number">Agency Licence Number <span class="text-red">*</span></label>
<input type="number" placeholder=" Agency Licence Number" class="form-control" id="agency_licence_number" name="agency_licence_number" required value="<?php echo isset($data->agency_licence_number)?$data->agency_licence_number:"";?>"  >
</div>
<div class="form-group">
			 		<label for="registration_serial_number_">Registration Serial Number  <span class="text-red">*</span></label>
<input type="number" placeholder=" Registration Serial Number " class="form-control" id="registration_serial_number_" name="registration_serial_number_" required value="<?php echo isset($data->registration_serial_number_)?$data->registration_serial_number_:"";?>"  >
</div>
<div class="form-group">
			 		<label for="status">Status <span class="text-red">*</span></label>
<select name="status" class="form-control" id="status"  required>
								<option value=""></option>
                        			<option value="Progress" <?php if(isset($data->status) && ($data->status == "Progress")){ echo "selected";}?>>Progress</option>
<option value="Waiting For Report" <?php if(isset($data->status) && ($data->status == "Waiting For Report")){ echo "selected";}?>>Waiting For Report</option>
<option value="Unsuccessful " <?php if(isset($data->status) && ($data->status == "Unsuccessful ")){ echo "selected";}?>>Unsuccessful </option>
<option value="Success" <?php if(isset($data->status) && ($data->status == "Success")){ echo "selected";}?>>Success</option>
</select>
</div>
<div class="form-group">
			 		<label for="flies_upload">Flies Upload </label>
<?php  
                        if( isset($data->flies_upload) && !empty($data->flies_upload)){ $req ="";}else{$req ="";}
						if(isset($data->flies_upload))
						{ 
							?>
							<input type="hidden"  name="fileOld" value="<?php echo isset($data->flies_upload) ?$data->flies_upload : "";?>">
							<a href="<?php echo base_url().'assets/images/'.$data->flies_upload ?>" download> <?php echo $data->flies_upload; ?> </a>
						<?php 
						} 
						?>
						<input type="file" placeholder=" Flies Upload" class="file-upload" id="flies_upload" name="flies_upload[]" <?php echo $req; ?> multiple value="" onchange='validate_fileType(this.value,&quot;flies_upload&quot;,&quot;jpg,doc etc.&quot;);' ><p id="error_flies_upload"></p>
</div>
</div>
                  <!-- /.box-body -->
                  <div class="box-footer">
                  	 <input type="submit" value="Save" name="save" class="btn btn-primary btn-color">
                  </div>
               </form>