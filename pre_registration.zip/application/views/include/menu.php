
<?php if(CheckPermission("Pre Registration Protal", "all_read,own_read")){ ?>
					<li class="<?=($this->router->class==="pre_registration_protal")?"active":"not-active"?>">
						<a href="<?php echo base_url("pre_registration_protal"); ?>"><i class="glyphicon glyphicon-send"></i> <span>Pre Registration Protal</span></a>
					</li><?php }?>
<?php if(CheckPermission("Registration Process", "all_read,own_read")){ ?>
					<li class="<?=($this->router->class==="registration_process")?"active":"not-active"?>">
						<a href="<?php echo base_url("registration_process"); ?>"><i class="glyphicon glyphicon-export"></i> <span>Registration Process</span></a>
					</li><?php }?>
<?php if(CheckPermission("Verification ", "all_read,own_read")){ ?>
					<li class="<?=($this->router->class==="verification_")?"active":"not-active"?>">
						<a href="<?php echo base_url("verification_"); ?>"><i class="glyphicon glyphicon-refresh"></i> <span>Verification </span></a>
					</li><?php }?>
<?php if(CheckPermission("Agency Report", "all_read,own_read")){ ?>
					<li class="<?=($this->router->class==="agency_report")?"active":"not-active"?>">
						<a href="<?php echo base_url("agency_report"); ?>"><i class="glyphicon glyphicon-tasks"></i> <span>Agency Report</span></a>
					</li><?php }?>
<?php if(CheckPermission("eHajj", "all_read,own_read")){ ?>
					<li class="<?=($this->router->class==="ehajj")?"active":"not-active"?>">
						<a href="<?php echo base_url("ehajj"); ?>"><i class="glyphicon glyphicon-tower"></i> <span>EHajj</span></a>
					</li><?php }?>
<?php if(CheckPermission("Support", "all_read,own_read")){ ?>
					<li class="<?=($this->router->class==="support")?"active":"not-active"?>">
						<a href="<?php echo base_url("support"); ?>"><i class="glyphicon glyphicon-share"></i> <span>Support</span></a>
					</li><?php }?>
<?php if(CheckPermission("Agency Details", "all_read,own_read")){ ?>
					<li class="<?=($this->router->class==="agency_details")?"active":"not-active"?>">
						<a href="<?php echo base_url("agency_details"); ?>"><i class="glyphicon glyphicon-user"></i> <span>Agency Details</span></a>
					</li><?php }?>
<?php if(CheckPermission("Data Transfer", "all_read,own_read")){ ?>
					<li class="<?=($this->router->class==="data_transfer")?"active":"not-active"?>">
						<a href="<?php echo base_url("data_transfer"); ?>"><i class="glyphicon glyphicon-send"></i> <span>Data Transfer</span></a>
					</li><?php }?>
<?php if(CheckPermission("Upload ", "all_read,own_read")){ ?>
					<li class="<?=($this->router->class==="upload_")?"active":"not-active"?>">
						<a href="<?php echo base_url("upload_"); ?>"><i class="glyphicon glyphicon-cloud-upload"></i> <span>Upload </span></a>
					</li><?php }?>
